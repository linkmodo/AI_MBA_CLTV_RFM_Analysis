
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// According to guidelines, API key MUST be from process.env.API_KEY
// and the client should be initialized like this.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

/**
 * Sends a prompt to the Gemini API and returns the text response.
 * @param prompt The text prompt to send to the model.
 * @returns A promise that resolves to the AI's text response.
 */
export const getAiAnalysis = async (prompt: string): Promise<string> => {
    try {
        // Guidelines recommend 'gemini-2.5-flash' for basic text tasks.
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        // Guidelines specify using response.text to get the output.
        return response.text;
    } catch (error) {
        console.error("Error getting AI analysis:", error);
        // Re-throw the error to be handled by the calling component.
        throw new Error("Failed to communicate with the AI service.");
    }
};
