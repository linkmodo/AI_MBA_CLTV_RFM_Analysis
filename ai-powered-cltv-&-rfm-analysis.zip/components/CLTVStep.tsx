
import React, { useState, useMemo, useEffect } from 'react';
import { RFMData, CLTVData } from '../types';
import { calculateCLTV } from '../utils/dataProcessing';
import Card from './common/Card';
import Loader from './common/Loader';
import { getAiAnalysis } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import AIActions from './common/AIActions';

interface CLTVStepProps {
    rfmData: RFMData[];
    setCltvData: (data: CLTVData[]) => void;
    goToNextStep: () => void;
    goToPrevStep: () => void;
}

const CLTVStep: React.FC<CLTVStepProps> = ({ rfmData, setCltvData, goToNextStep, goToPrevStep }) => {
    const [profitMargin, setProfitMargin] = useState(25); // Default 25%
    const [discountRate, setDiscountRate] = useState(10); // Default 10%
    const [isChurnOverridden, setIsChurnOverridden] = useState(false);
    const [churnRateOverrideValue, setChurnRateOverrideValue] = useState(50); // Default 50%
    const [aiStrategies, setAiStrategies] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);

    const baseChurnRate = useMemo(() => {
        if (rfmData.length === 0) return 0;
        const repeatCustomers = rfmData.filter(r => r.Frequency > 1).length;
        const retentionRate = repeatCustomers / rfmData.length;
        return 1 - retentionRate;
    }, [rfmData]);

    const cltvResults = useMemo(() => {
        if (rfmData.length === 0) return [];
        const churnOverride = isChurnOverridden ? churnRateOverrideValue / 100 : null;
        return calculateCLTV(rfmData, profitMargin / 100, discountRate / 100, churnOverride);
    }, [rfmData, profitMargin, discountRate, isChurnOverridden, churnRateOverrideValue]);

    useEffect(() => {
        if (cltvResults.length > 0) {
            setCltvData(cltvResults);
        }
    }, [cltvResults, setCltvData]);
    
    const summaryMetrics = useMemo(() => {
        const totalProjectedValue = cltvResults.reduce((acc, segment) => acc + (segment.AvgCLTV * segment.CustomerCount), 0);
        const effectiveChurnRate = isChurnOverridden ? churnRateOverrideValue / 100 : baseChurnRate;
        const avgLifetime = effectiveChurnRate > 0 ? 1 / effectiveChurnRate : Infinity;
        
        return {
            totalProjectedValue,
            avgLifetime,
            effectiveChurnRate,
        };
    }, [cltvResults, baseChurnRate, isChurnOverridden, churnRateOverrideValue]);

    const handleAiAnalysis = async () => {
        setIsAiLoading(true);
        setAiStrategies('');
        const cltvString = cltvResults.slice(0, 5).map(c => `${c.Segment}: Avg CLTV $${c.AvgCLTV.toFixed(2)}`).join(', ');
        const usedChurnRate = isChurnOverridden ? churnRateOverrideValue : (baseChurnRate * 100);

        const prompt = `Our CLTV model uses the following parameters:
- **Profit Margin:** ${profitMargin}%
- **Annual Discount Rate:** ${discountRate}%
- **Effective Churn Rate:** ${usedChurnRate.toFixed(2)}%

The resulting average CLTV for each key customer segment is: ${cltvString}.

Provide actionable, strategic advice to maximize the total customer lifetime value across our entire customer base. Structure your response with a separate bulleted list for each of the following objectives:
1.  **Retention Strategies:** What specific actions can we take to reduce churn, especially for "At Risk" and "Customers Needing Attention" segments?
2.  **Growth Strategies:** How can we increase the purchase frequency and average order value for high-potential segments like "Potential Loyalists" and "Loyal Customers"?
3.  **VIP Strategies:** What premium services, loyalty programs, or exclusive offers can we use to maximize value from our "Champions" and ensure they remain advocates?`;

        try {
            const result = await getAiAnalysis(prompt);
            setAiStrategies(result);
        } catch (err) {
            setAiStrategies('Failed to get AI strategies. Please try again.');
            console.error(err);
        } finally {
            setIsAiLoading(false);
        }
    };
    
    if (rfmData.length === 0) {
        return (
            <Card>
                <p>Could not calculate CLTV. Please go back to the RFM step.</p>
                 <button onClick={goToPrevStep} className="mt-4 px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    &larr; Back
                </button>
            </Card>
        );
    }
    
    return (
        <Card>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Step 5: Customer Lifetime Value (CLTV) Prediction</h2>
            
            <div className="bg-gray-50 p-4 rounded-lg border mb-8">
                <h3 className="text-lg font-medium text-gray-800 mb-4">CLTV Model Parameters</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label htmlFor="profit-margin" className="block text-sm font-medium text-gray-700">Profit Margin (%)</label>
                        <p className="text-xs text-gray-500 mb-1">Your average profit on each sale.</p>
                        <input
                            type="number"
                            id="profit-margin"
                            value={profitMargin}
                            onChange={(e) => setProfitMargin(Number(e.target.value))}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-white text-gray-900"
                        />
                    </div>
                    <div>
                        <label htmlFor="discount-rate" className="block text-sm font-medium text-gray-700">Annual Discount Rate (%)</label>
                        <p className="text-xs text-gray-500 mb-1">Accounts for the time value of money.</p>
                        <input
                            type="number"
                            id="discount-rate"
                            value={discountRate}
                            onChange={(e) => setDiscountRate(Number(e.target.value))}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-white text-gray-900"
                        />
                    </div>
                    <div>
                        <label htmlFor="churn-override" className="block text-sm font-medium text-gray-700">Churn Rate Override</label>
                        <p className="text-xs text-gray-500 mb-1">Calculated churn is {(baseChurnRate * 100).toFixed(2)}%.</p>
                        <div className="flex items-center mt-2">
                            <input id="churn-override-toggle" type="checkbox" checked={isChurnOverridden} onChange={e => setIsChurnOverridden(e.target.checked)} className="h-4 w-4 text-indigo-600 border-gray-300 rounded"/>
                            <label htmlFor="churn-override-toggle" className="ml-2 text-sm text-gray-600">Enable Override</label>
                        </div>
                        {isChurnOverridden && (
                            <input
                                type="number"
                                id="churn-override"
                                value={churnRateOverrideValue}
                                onChange={(e) => setChurnRateOverrideValue(Number(e.target.value))}
                                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-white text-gray-900"
                                placeholder="Enter %"
                            />
                        )}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
                <div className="bg-gray-100 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Projected Total CLTV</p>
                    <p className="text-2xl font-bold text-gray-900">${summaryMetrics.totalProjectedValue.toLocaleString('en-US', { maximumFractionDigits: 0 })}</p>
                </div>
                <div className="bg-gray-100 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Avg. Customer Lifetime</p>
                    <p className="text-2xl font-bold text-gray-900">{isFinite(summaryMetrics.avgLifetime) ? `${summaryMetrics.avgLifetime.toFixed(2)} periods` : 'Infinite'}</p>
                </div>
                <div className="bg-gray-100 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Effective Churn Rate</p>
                    <p className="text-2xl font-bold text-gray-900">{(summaryMetrics.effectiveChurnRate * 100).toFixed(2)}%</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                    <h3 className="font-medium text-gray-800 mb-2">Average CLTV by Customer Segment</h3>
                     <div style={{ width: '100%', height: 300 }}>
                         <ResponsiveContainer>
                            <BarChart data={cltvResults} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="Segment" tick={{fontSize: 10}}/>
                                <YAxis tickFormatter={(value) => `$${(Number(value)/1000).toFixed(0)}k`}/>
                                <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
                                <Bar dataKey="AvgCLTV" fill="#4f46e5" name="Average CLTV" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                 <div>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="font-medium text-gray-800">AI-Powered CLTV Growth Strategies</h3>
                        {aiStrategies && !isAiLoading && <AIActions text={aiStrategies} filename="cltv_strategies" />}
                    </div>
                     <button onClick={handleAiAnalysis} disabled={isAiLoading} className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400">
                        <SparklesIcon className="h-4 w-4 mr-2" />
                        {isAiLoading ? 'Analyzing...' : 'Get AI Strategies'}
                    </button>
                    <div className="mt-4 p-4 bg-gray-50 rounded-md h-64 overflow-y-auto border">
                        {isAiLoading && <Loader text="AI is developing growth strategies..." />}
                        {aiStrategies ? (
                            <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: aiStrategies.replace(/\n/g, '<br />') }} />
                        ) : (
                            <p className="text-sm text-gray-500">Click the button to get AI-powered strategies to boost CLTV.</p>
                        )}
                    </div>
                </div>
            </div>

            <div className="mt-8 flex justify-between">
                <button onClick={goToPrevStep} className="px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    &larr; Back
                </button>
                <button onClick={goToNextStep} className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700">
                    View Summary & Export &rarr;
                </button>
            </div>
        </Card>
    );
};

export default CLTVStep;
