import React, { useMemo, useState, useEffect } from 'react';
import { Transaction, RFMData } from '../types';
import { calculateRFM } from '../utils/dataProcessing';
import Card from './common/Card';
import Loader from './common/Loader';
import { getAiAnalysis } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import AIActions from './common/AIActions';

interface RFMStepProps {
    cleanedTransactions: Transaction[];
    setRfmData: (data: RFMData[]) => void;
    goToNextStep: () => void;
    goToPrevStep: () => void;
}

const RFMStep: React.FC<RFMStepProps> = ({ cleanedTransactions, setRfmData, goToNextStep, goToPrevStep }) => {
    const [aiRecommendations, setAiRecommendations] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);

    const rfmResults = useMemo(() => {
        if (cleanedTransactions.length === 0) return [];
        return calculateRFM(cleanedTransactions);
    }, [cleanedTransactions]);

    useEffect(() => {
        if(rfmResults.length > 0) {
            setRfmData(rfmResults);
        }
    }, [rfmResults, setRfmData]);

    const segmentDistribution = useMemo(() => {
        const distribution: { [key: string]: number } = {};
        rfmResults.forEach(r => {
            distribution[r.Segment] = (distribution[r.Segment] || 0) + 1;
        });
        return Object.entries(distribution)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [rfmResults]);

    const recencyDistribution = useMemo(() => {
        if (!rfmResults) return [];
        const distribution = Array(5).fill(0).map((_, i) => ({ name: `Score ${i + 1}`, Customers: 0 }));
        rfmResults.forEach(r => {
            if (r.R_Score >= 1 && r.R_Score <= 5) {
                 distribution[r.R_Score - 1].Customers++;
            }
        });
        return distribution;
    }, [rfmResults]);

    const frequencyDistribution = useMemo(() => {
         if (!rfmResults) return [];
        const distribution = Array(5).fill(0).map((_, i) => ({ name: `Score ${i + 1}`, Customers: 0 }));
        rfmResults.forEach(r => {
            if (r.F_Score >= 1 && r.F_Score <= 5) {
                distribution[r.F_Score - 1].Customers++;
            }
        });
        return distribution;
    }, [rfmResults]);

    const monetaryDistribution = useMemo(() => {
        if (!rfmResults) return [];
        const distribution = Array(5).fill(0).map((_, i) => ({ name: `Score ${i + 1}`, Customers: 0 }));
        rfmResults.forEach(r => {
            if (r.M_Score >= 1 && r.M_Score <= 5) {
                distribution[r.M_Score - 1].Customers++;
            }
        });
        return distribution;
    }, [rfmResults]);

    const handleAiAnalysis = async () => {
        setIsAiLoading(true);
        setAiRecommendations('');
        const distributionString = segmentDistribution.map(s => `${s.name}: ${s.value} customers`).join(', ');
        const prompt = `Here is the RFM segmentation of our customer base: ${distributionString}. For each of the top 5 segments, provide actionable marketing recommendations in a bulleted list to engage them effectively.`;
        
        try {
            const result = await getAiAnalysis(prompt);
            setAiRecommendations(result);
        } catch (err) {
            setAiRecommendations('Failed to get AI recommendations. Please try again.');
            console.error(err);
        } finally {
            setIsAiLoading(false);
        }
    };
    
    if (rfmResults.length === 0) {
         return (
            <Card>
                <p>Could not perform RFM Analysis. Please ensure your data is properly cleaned.</p>
                <button onClick={goToPrevStep} className="mt-4 px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    &larr; Back
                </button>
            </Card>
        );
    }

    return (
        <Card>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Step 4: RFM Analysis & Segmentation</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
                <div>
                    <h3 className="font-medium text-gray-800 mb-2">Customer Segment Distribution</h3>
                    <div style={{ width: '100%', height: 300 }}>
                         <ResponsiveContainer>
                            <BarChart data={segmentDistribution} layout="vertical" margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis type="number" />
                                <YAxis type="category" dataKey="name" tick={{fontSize: 12}} />
                                <Tooltip />
                                <Bar dataKey="value" fill="#4f46e5" name="Number of Customers" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                 <div>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="font-medium text-gray-800">AI-Powered Marketing Recommendations</h3>
                        {aiRecommendations && !isAiLoading && <AIActions text={aiRecommendations} filename="rfm_recommendations" />}
                    </div>
                     <button onClick={handleAiAnalysis} disabled={isAiLoading} className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400">
                        <SparklesIcon className="h-4 w-4 mr-2" />
                        {isAiLoading ? 'Analyzing...' : 'Get AI Recommendations'}
                    </button>
                    <div className="mt-4 p-4 bg-gray-50 rounded-md h-64 overflow-y-auto border">
                        {isAiLoading && <Loader text="AI is crafting marketing strategies..." />}
                        {aiRecommendations ? (
                            <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: aiRecommendations.replace(/\n/g, '<br />') }} />
                        ) : (
                            <p className="text-sm text-gray-500">Click the button to get AI-powered marketing recommendations for your customer segments.</p>
                        )}
                    </div>
                </div>
            </div>

            <div className="border-t pt-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">RFM Score Distributions</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                        <h4 className="font-medium text-gray-800 text-center mb-2">Recency Score</h4>
                        <div style={{ width: '100%', height: 250 }}>
                            <ResponsiveContainer>
                                <BarChart data={recencyDistribution}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" tick={{fontSize: 12}} />
                                    <YAxis />
                                    <Tooltip />
                                    <Bar dataKey="Customers" fill="#8884d8" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                     <div>
                        <h4 className="font-medium text-gray-800 text-center mb-2">Frequency Score</h4>
                        <div style={{ width: '100%', height: 250 }}>
                            <ResponsiveContainer>
                                <BarChart data={frequencyDistribution}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" tick={{fontSize: 12}} />
                                    <YAxis />
                                    <Tooltip />
                                    <Bar dataKey="Customers" fill="#82ca9d" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                     <div>
                        <h4 className="font-medium text-gray-800 text-center mb-2">Monetary Score</h4>
                        <div style={{ width: '100%', height: 250 }}>
                            <ResponsiveContainer>
                                <BarChart data={monetaryDistribution}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" tick={{fontSize: 12}} />
                                    <YAxis />
                                    <Tooltip />
                                    <Bar dataKey="Customers" fill="#ffc658" />
                                 </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>
            </div>

             <h3 className="font-medium text-gray-800 mt-8 mb-2">RFM Data Sample</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            {Object.keys(rfmResults[0]).map(key => 
                                <th key={key} className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{key}</th>
                            )}
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {rfmResults.slice(0, 5).map((row, index) => (
                            <tr key={index}>
                                {Object.values(row).map((val, i) => <td key={i} className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{val}</td>)}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="mt-8 flex justify-between">
                <button onClick={goToPrevStep} className="px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    &larr; Back
                </button>
                <button onClick={goToNextStep} className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700">
                    Predict CLTV &rarr;
                </button>
            </div>
        </Card>
    );
};

export default RFMStep;